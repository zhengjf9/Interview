写出完整版的strcpy函数

```
char * strcpy( char *strDest, const char *strSrc ) 
{
 assert( (strDest != NULL) && (strSrc != NULL) );

 char *address = strDest; 

 while( (*strDest++ = * strSrc++) != ‘\0’ ); 

 return address;
 }
```

临时对象效率问题：

