# C++

##RTTI

在C++ 环境中﹐头文件(header file) 含有类之定义(class definition)亦即包含有关类的结构资料(representational 
information)。但是﹐这些资料只供编译器(compiler)使用﹐编译完毕后并未留下来﹐所以在执行时期(at runtime) ﹐无法得知对象的类资料﹐包括类名称、数据成员名称与类型、函数名称与类型等等。例如﹐两个类Figure和Circle﹐其之间为继承关系。 
若有如下指令﹕ 
Figure *p; 
p = new Circle(); 
Figure &q = *p; 

在执行时﹐p指向一个对象﹐但欲得知此对象之类资料﹐就有困难了。同样欲得知q 所参考(reference) 
对象的类资料﹐也无法得到。RTTI(Run-Time Type Identification)就是要解决这困难﹐也就是在执行时﹐您想知道指针所指到或参考到的对象类型时﹐该对象有能力来告诉您。随着应用场合之不同﹐所需支持的RTTI范围也不同。最单纯的RTTI包括﹕ 
●类识别(class identification)──包括类名称或ID。 
●继承关系(inheritance relationship)──支持执行时期的「往下变换类型」(downward casting)﹐亦即动态变换类型(dynamic casting) 。

**RTTI可能伴随的副作用** 
​      RTTI最主要的副作用是﹕程序员可能会利用RTTI来支持其「复选」(multiple-selection)方法﹐而不使用虚函数(virtual function)方法。 
虽然这两种方法皆能达到多态化(polymorphism) ﹐但使用复选方法﹐常导致违反著名的「开放╱封闭原则」(open/closed principle) 〔注2 〕。反之﹐使用虚函数方法则可合乎这个原则. 
​      Circle和Square皆是由Figure所派生出来的子类﹐它们各有自己的draw()函数。当C++ 提供了RTTI﹐就可写个函数如下﹕ 
void drawing( Figure *p ) 
{ 
​    if( typeid(*p).name() == "Circle" ) 
​      ((Circle*)p) -> draw(); 
​    if( typeid(*p).name() == "Rectangle" ) 
​      ((Rectangle*)p) -> draw(); 
} 
​    虽然drawing() 函数也具有多型性﹐但它与Figure类体系的结构具有紧密的相关性。当Figure类体系再派生出子类时﹐drawing() 函数的内容必须多加个if指令。因而违反了「开放╱封闭原则」﹐如下﹕ 
​    很显然地﹐drawing() 函数应加以修正。 
​    想一想﹐如果C++ 并未提供RTTI﹐则程序员毫无选择必须使用虚函数来支持drawing() 函数的多型性。于是程序员将draw()宣告为虚函数﹐并写drawing() 如下﹕ 
void drawing(Figure *p) 
{ p->draw(); } 

   如此﹐Figure类体系能随时派生类﹐而不必修正drawing() 函数。亦即﹐Figure体系有个稳定的接口(interface) 
﹐drawing() 使用这接口﹐使得drawing() 
函数也稳定﹐不会随Figure类体系的扩充而变动。这是封闭的一面。而这稳定的接口并未限制Figure体系的成长﹐这是开放的一面。因而合乎「开放╱封闭」原则﹐软件的结构会更具弹性﹐更易于随环境而不断成长。

## 虚函数和纯虚函数的异同点

```
虚函数与纯虚函数在他们的子类中都可以被重写。它们的区别是：
（1）纯虚函数只有定义，没有实现；而虚函数既有定义，也有实现的代码。
  纯虚函数一般没有代码实现部分，如
virtual void print() = 0;
   而一般虚函数必须要有代码的实现部分，否则会出现函数未定义的错误。
virtual void print()
{   printf("This is virtual function\n");  }
（2）包含纯虚函数的类不能定义其对象，而包含虚函数的则可以。
```
## 栈溢出几种情况

一、局部数组过大。当函数内部的数组过大时，有可能导致堆栈溢出。

二、递归调用层次太多。递归函数在运行时会执行压栈操作，当压栈次数太多时，也会导致堆栈溢出。

三、指针或数组越界。这种情况最常见，例如进行字符串拷贝，或处理用户输入等等。